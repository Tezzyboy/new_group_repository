#1)Clone the repository
--git clone https://github.com/Tezzyboy/new_group_repository.git
--cd new_group_repository/Assignment_2_group_project

#2)Open in Unity
--Open Unity Hub
--Click Add Project → select this folder
--Use the same Unity version as in ProjectSettings/ProjectVersion.txt

#3)Run the game
--Open the main scene (inside Assets/Scenes/)
--Click ▶ (Play) in Unity Editor
