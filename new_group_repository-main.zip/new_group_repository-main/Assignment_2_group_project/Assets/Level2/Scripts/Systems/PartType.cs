public enum PartType
{
    Mast,     
    Nacelle,  
    Blade     
}